# app/schemas.py
from pydantic import BaseModel, Field
from typing import Optional, List
from uuid import UUID
from decimal import Decimal
from datetime import datetime

class AccountBase(BaseModel):
    currency: str = Field(..., min_length=3, max_length=3)

class AccountCreate(AccountBase):
    pass

class AccountOut(AccountBase):
    id: int
    user_id: int  # Изменено на UUID
    balance: Decimal


class BalanceUpdate(BaseModel):
    amount: Decimal
    operation: str  # 'debit' or 'credit'

class BalanceResponse(BaseModel):
    balance: Decimal

class Token(BaseModel):
    access_token: str
    token_type: str

class TokenData(BaseModel):
    username: str
